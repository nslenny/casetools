var searchData=
[
  ['goldbach_2ec_2',['goldbach.c',['../goldbach_8c.html',1,'']]]
];
