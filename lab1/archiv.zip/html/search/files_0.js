var searchData=
[
  ['calculate_5fprimes_2ec_5',['calculate_primes.c',['../calculate__primes_8c.html',1,'']]]
];
