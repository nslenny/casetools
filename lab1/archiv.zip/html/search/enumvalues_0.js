var searchData=
[
  ['calculate_5fprimes_11',['calculate_primes',['../goldbach_8c.html#a9c3519f94671aef82fa76bc7a2a444c7a1ccbc4e6f5b0ad045f03a5dc4a4e21ca',1,'goldbach.c']]]
];
