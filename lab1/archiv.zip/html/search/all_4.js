var searchData=
[
  ['primes_2ec_5',['primes.c',['../primes_8c.html',1,'']]]
];
