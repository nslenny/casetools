var searchData=
[
  ['primes_2ec_7',['primes.c',['../primes_8c.html',1,'']]]
];
