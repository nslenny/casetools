var searchData=
[
  ['bib_10',['bib',['../goldbach_8c.html#a9c3519f94671aef82fa76bc7a2a444c7',1,'goldbach.c']]]
];
