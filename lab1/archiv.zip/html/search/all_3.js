var searchData=
[
  ['primes_2ec_4',['primes.c',['../primes_8c.html',1,'']]]
];
