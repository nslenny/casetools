var searchData=
[
  ['goldbach_2ec_6',['goldbach.c',['../goldbach_8c.html',1,'']]]
];
