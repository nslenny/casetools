var searchData=
[
  ['calculate_5fprimes_0',['calculate_primes',['../calculate__primes_8c.html#abf230b1e1fa8e0bc361e0b7551c84731',1,'calculate_primes.c']]],
  ['calculate_5fprimes_2ec_1',['calculate_primes.c',['../calculate__primes_8c.html',1,'']]]
];
