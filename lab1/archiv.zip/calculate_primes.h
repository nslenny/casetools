int calculate_primes(int primes[], int n);
